//_AddPermissions('Network')
console.log('Main')
let isNew = true;
const firebaseConfig = {
    apiKey: "AIzaSyDa8-30xelWHYyGKw82givvwt8eM8KmMqE",
    authDomain: "bhc-mobile-app.firebaseapp.com",
    projectId: "bhc-mobile-app",
    storageBucket: "bhc-mobile-app.appspot.com",
    messagingSenderId: "309220637622",
    appId: "1:309220637622:web:b2078df1b709be23e01f17", 
    measurementId: "G-VS9ZLB9C6B"
};

let myriadpro = 'Misc/MYRIADPRO-REGULAR.OTF';

ui.script('Misc/firebase-app.js');
ui.script('Misc/firebase-auth.js')
ui.script('Misc/firebase-firestore.js')
ui.script('Misc/firebase-storage.js')
ui.script('htmlElement.js')
ui.script('lottie.js')

//Main class for the app
class Main extends App
{
    //Called when app starts.
    onStart() {
        if (isNew) this.loginScreen();
        else this.mainScreen();
        ui.setThemeColor('#6E302B', '#593B38')
        firebase.initializeApp(firebaseConfig)
    }
    
    loginScreen() {
        
        let loginScreenUi = ui.addLayout("main", 'linear', 'fillxy,center', 1, 1);
        loginScreenUi.setChildMargins(0, 0, 0, 0.05);
        
        let lottieAnim = ui.addHTMLElement(loginScreenUi, 'lottie-player',1,-1);
        lottieAnim.element.setAttribute('src', './Misc/home2.json');

        lottieAnim.element.setAttribute('speed',1)
        
        let text = ui.addText(loginScreenUi, 'Welcome To The BHC App !', '', -1 , -1);
        text.fontFile = myriadpro;
        
        let emailBar = ui.addTextField(loginScreenUi, '', 'Outlined,Secondary,Email', 0.85, -1)
        emailBar.setStartAdornment('mail','Icon')
        emailBar.label = 'enter your email';
        
        let passBar = ui.addTextField(loginScreenUi, '', 'Outlined,Secondary,Password', 0.85, -1)
        passBar.setStartAdornment('lock','Icon')
        passBar.label = 'enter your password';
        
        let forgotPassText = ui.addText(loginScreenUi, 'Forgot password ?', '', -1 , -1);
        forgotPassText.fontFile = 'Misc/lexend.ttf';
        
        let noAccountText = ui.addText(loginScreenUi, 'I dont have an account', 'left', -1, -1);
        noAccountText.fontFile = 'Misc/lexend.ttf';
        noAccountText.setOnTouch(function(){
            loginScreenUi.hide()
            signUpScreen();
        });
        
        let loginBtn = ui.addButton(loginScreenUi, 'LogIn', 'Primary', 0.85, -1)
        loginBtn.setOnTouch(function(){
            const provider = new firebase.auth.GoogleAuthProvider();
    firebase.auth().signInWithEmailAndPassword(emailBar.text, passBar.text)
    .then((userCredential) => {
        let user = userCredential.user;
        loginScreenUi.hide()
        mainScreen()
    })
    .catch((error) => {
        var errorCode = error.code;
        var errorMessage = error.message;
        alert(errorMessage)
    });
        })
    }
    
    
}

function mainScreen() {
    let mainScreenUi = ui.addLayout("main", 'linear', 'fillxy', 1, 1)
    let db = firebase.firestore();
    let fileURL = 'none'
    let nav = [
        ["Home","dashboard"],
        ["Find", "search"],
        ["Issues","call_made"],
        ["You","person_circle"]
    ] 
    
    let userActionsList = [
        ["Rent","View your rental statements"],
        ["Account Issues","View any issues you've logged or submissons and clarify"]
    ]

    let frame = ui.addLayout(mainScreenUi, 'slide', 'vcenter,fillxy', 1, 1)
    
    
    this.dashboard =  ui.addLayout(frame, "Linear", "HCenter, Top", 1, 1)
    this.dashboard.setChildMargins(0, 0.05, 0, 0)
    
    let dashboardCard = ui.addLayout(this.dashboard,'Absolute', '', 0.85, 0.2)
    dashboardCard.backImage = 'Img/leaf.png'
    dashboardCard.cornerRadius = 5
    //dashboardCard.borderColor = 'black'
    dashboardCard.borderStyle = 'solid'
    
    let bhclogo = ui.addImage(dashboardCard, 'Img/bhcTransparent.png', '', 0.2, -1)
    bhclogo.setPosition('15.2rem', 0)
    
    let welcomeText = ui.addText(dashboardCard, `Hello ${getUserInfo('name')} 👋`, '', -1, -1)
    welcomeText.setPosition('0.8rem', '7.5rem')
    welcomeText.textSize = 22;
    
    let optionsList = ui.addList(this.dashboard, userActionsList, 'Dense, Elevated', 0.85)
    
    this.find = ui.addLayout(frame, "Linear", "VCenter", 1, 1)
    
    
    let viewRentBtn = ui.addButton(this.dashboard, 'View Your Rent Or TPS Statement', 'Primary', 0.85, -1)
    
    let viewApplicationBtn = ui.addButton(this.dashboard, 'View Application Procedures', 'Default', 0.85, -1)
    
    this.issues = ui.addLayout(frame, "Linear", "HCenter, Top", 1, 1)
    this.issues.setChildMargins(0, 0.05, 0, 0.02)
    
    let searchFAQ = ui.addTextField(this.issues, '', 'Search,Filled,Secondary', 0.85, -1)
    searchFAQ.setEndAdornment('search', 'Icon')
    searchFAQ.label = "Search The FAQ's"
    
    let FAQList = [
        ["Why do I need a conveyancer to transfer property?", "Only a conveyancer can transfer property according to the laws of Botswana"],
        ["When I buy a BHC property. Do your lawyers process transfer and bonding of this property?", "No. The purchaser has to engage a conveyancer for the transfer and bonding of a property."],
        ["I am not a citizen of Botswana am I eligible to buy a BHC house?", "Only citizens and citizen-controlled companies are eligible to purchase BHC properties. (Citizens controlled companies refer to those with a majority shareholders being Botswana citizens)."],
        ["How many houses can my company be allowed to buy?", "A company can buy one or more houses from BHC depending on availability."],
        ["Can I sell the property I am renting from BHC?", "BHC alone has the right to sell its properties."]
    ];
    
    let faqUi = ui.addLayout(this.issues, 'linear', 'scrollx', 0.85, 0.6)
    
    let faqList = ui.addList(faqUi, FAQList, 'Dense',-1, 1)
    
    let reportBtn = ui.addButton(this.issues, 'Report An Issue', 'Primary', 0.85, -1)
    reportBtn.icon = 'flag'
    reportBtn.setOnTouch(function(){
        let bottomDrwLay = ui.addLayout(null, 'linear')
        bottomDrwLay.setChildMargins(0, 0.05, 0, 0.05)
        let bottomDrw = ui.addDrawer(bottomDrwLay, 'bottom', 0.85)
        
        let issueField = ui.addTextField(bottomDrwLay, '', 'Filled', 0.8, -1)
        issueField.label = 'enter issue title'
        
        let issuetypes = ["Issue With House", "Change Of Tenancy"]
        let issueSelect = ui.addSelect(bottomDrwLay, issuetypes, "Filled", 0.8, -1)
        issueSelect.label = 'select type of issue'
        
        let houseproblemtypes = ["Electrical", "Plumbing", "Carpentry", "Masonary", "External"]
        let houseProblemSelect = ui.addSelect(bottomDrwLay, houseproblemtypes, "Filled", 0.8, -1)
        houseProblemSelect.label = 'select a house problem'
        
        let issueDesc = ui.addTextField(bottomDrwLay, '', 'Multiline, Filled, Outline', 0.8, -1)
        issueDesc.label = 'please describe your issue';
        issueDesc.setRows(5, 15)
        
        let attachImage = ui.addButton(bottomDrwLay, 'Attach An Image', 'Outlined,Secondary, Upload', 0.8, -1)
        attachImage.setOnFileSelect((file)=>{
            submitReportBtn.disabled = true;
            const image = file[0];
            const storage = firebase.storage().ref();
            const imageRef = storage.child(getUserInfo('name') + 'Report');
            
            const uploadTask = imageRef.put(image);
            uploadTask.then(snapshot => {
                uploadTask.snapshot.ref.getDownloadURL().then(downloadURL => {
                    fileURL = downloadURL;
                    submitReportBtn.disabled = false;
                });
            })
            .catch(err => {
                //alert(err);
            });
        })
        
        let submitReportBtn = ui.addButton(bottomDrwLay, 'Submit Report', 'Filled, Secondary', 0.8, -1)
        submitReportBtn.setOnTouch(function(){    
            db.collection("reports&Faults").doc(getUserInfo('name')).set({
                IssueTitle: issueField.text,
                IssueCategory: issueSelect.value,
                HouseIssue: houseProblemSelect.value,
                UserDescription: issueDesc.text,
                UserImage: fileURL ? fileURL : 'none',
                CalculatedSeverity: getSeverity(issueCategory.GetText(), homeIssueType.GetText()),
                email: getUserInfo('email')
            })
            .then(() => {
                bottomDrw.hide()
                setTimeout(() => {
                    ui.showPopup('We received your report, we will email you back.','top', null, 'Sure');
                }, 570);
            })
        })
        bottomDrw.show();
    })
    let enquireBtn = ui.addButton(this.issues, 'Submit A Question', 'Primary', 0.85, -1)
    enquireBtn.icon = 'message'
    
    this.account = ui.addLayout(frame, "Linear", "FillXY, Top", 1, 1)
    let accountCircle = ui.addImage( this.account, 'Img/user.png', '', 0.5)
    
    let bottomNav = ui.addBottomNavbar(mainScreenUi, nav, 'Hidelabels', 1, -1)
    bottomNav.setOnChange((text, index)=>{
        frame.goto(index)
    })
    
    bottomNav.labels = false;
}
function signUpScreen() {
    let signUpScreenUi = ui.addLayout("main", 'linear', 'fillxy,top');
    signUpScreenUi.setChildMargins(0, 0.05, 0, 0.05)
    
    let welcomeTxt = ui.addText(signUpScreenUi, 'Welcome To The BHC App !\nLets Make You An Account', '', -1, -1);
    
    let nameBar = ui.addTextField(signUpScreenUi, '', 'Filled', 0.85, -1)
    nameBar.setStartAdornment("person", "Icon")
    nameBar.label = 'enter your name here'
    
    let emailBar = ui.addTextField(signUpScreenUi, '', 'Filled, Email', 0.85, -1)
    emailBar.setStartAdornment("mail", "Icon")
    emailBar.label = 'enter your email here'
    
    let phoneBar = ui.addTextField(signUpScreenUi, '', 'Filled, Number', 0.85, -1)
    phoneBar.setStartAdornment("phone", "Icon")
    phoneBar.label = 'enter yout number here';
    
    let passBar = ui.addTextField(signUpScreenUi, '', 'Filled, Password', 0.85, -1)
    passBar.setStartAdornment("lock", "Icon")
    passBar.setEndAdornment('visibility_off','Icon,Touchable')
    passBar.label = 'enter your password here';
    
    let secPassBar = ui.addTextField(signUpScreenUi, '', 'Filled, Password', 0.85, -1)
    secPassBar.setStartAdornment("lock", "Icon")
    secPassBar.setEndAdornment('visibility_off','Icon,Touchable')
    secPassBar.label = 're-type your password';
    
    let alternativeSignUpTxt = ui.addText(signUpScreenUi, 'You can also sign up using:', '', -1, -1)
    alternativeSignUpTxt.fontFile = 'Misc/lexend.ttf';
    
    let alternativesLay = ui.addLayout(signUpScreenUi, 'linear', 'horizontal, left')
    
    let googleSignUpBtn = ui.addButton(alternativesLay, 'android', 'Primary, Icon')
    
    let facebookSignUpBtn = ui.addButton(alternativesLay, 'facebook', 'Primary, Icon')
    
    let appleSignUpBtn = ui.addButton(alternativesLay, 'android', 'Primary, Icon')
    
    let signUpBtn = ui.addButton(signUpScreenUi, 'Sign up', 'Primary', 0.85, -1)
}

function signInUserWithEmail(email, password) {
    
}

function signUpUserWithEmail(email, password, phoneNumber, displayName) {
    let fixedNumber = '+267' + phoneNumber;

    const provider = new firebase.auth.GoogleAuthProvider();
    firebase.auth().createUserWithEmailAndPassword(email, password)
    .then((userCredential) => {
        const user = firebase.auth().currentUser;

        /* Update User Names.. */
        /* Fake Update Phone Number, We Would Need To Verify It*/

        user.updateProfile({
            displayName: displayName,
            phoneNumber: fixedNumber
        })
        .then(() => {
            const App = new Main()
        App.mainScreen()
            })
        })
        .catch((error) => {
            var errorCode = error.code;
            var errorMessage = error.message;
            alert(errorMessage)
        });
}

function getUserInfo(id){
    const user = firebase.auth().currentUser;
    if (id == 'name') return user.displayName;
    if (id == 'email') return user.email;
    if (id == 'phoneNumber') return '700000000';
}
